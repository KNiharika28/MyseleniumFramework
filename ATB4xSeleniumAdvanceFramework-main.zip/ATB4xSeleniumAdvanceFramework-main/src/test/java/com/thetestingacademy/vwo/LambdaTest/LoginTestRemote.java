package com.thetestingacademy.vwo.LambdaTest;

public class LoginTestRemote {
    // Test wil run on LambdaTest
}
