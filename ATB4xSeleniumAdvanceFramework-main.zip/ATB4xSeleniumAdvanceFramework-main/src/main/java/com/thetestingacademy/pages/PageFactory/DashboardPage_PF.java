package com.thetestingacademy.pages.PageFactory;

public class DashboardPage_PF {
}
