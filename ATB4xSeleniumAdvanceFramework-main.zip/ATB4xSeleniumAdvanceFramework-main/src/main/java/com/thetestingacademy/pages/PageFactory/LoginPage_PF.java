package com.thetestingacademy.pages.PageFactory;

public class LoginPage_PF {
}
