package com.thetestingacademy.utils;

public class Constants {
}
